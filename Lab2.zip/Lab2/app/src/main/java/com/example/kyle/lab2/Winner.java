package com.example.kyle.lab2;

public enum Winner {
    player1, player2, tie, inProgress
}
