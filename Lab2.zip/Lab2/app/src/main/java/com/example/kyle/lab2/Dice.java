package com.example.kyle.lab2;

public enum Dice {
    die1, die2, die3, die4, die5, die6
}
